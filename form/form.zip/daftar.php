<h4>Register Data</h4>
<p><label for='nama'><span>Nama </span></label><input class='input-field' placeholder='Nama Customer' type='text' id='nama' style='width: 170px;'></p>
<p><label for='Username'><span>HDSN </span></label><input class='input-field' placeholder='HDSN Costumer' type='text' id='username' style='width: 170px;'></p>
<p><label for='password'><span>Password </span></label><input class='input-field' placeholder='Password' type='password' id='password' style='width: 170px;'></p>
<p><label for='durasi'><span>Durasi  </span></label><select id='durasi' class='select-field' style='width: 170px;'>
<option value='3'>3 Hari</option>
<option value='7'>7 Hari</option>
<option value='14'>14 Hari</option>
<option value='30'>30 Hari</option>
</select></p>
<p><label for='submit'><span></span></label><p><input type='submit' class='button btn btn-warning btn-large' name='submit' value='Submit' onclick="proses();"/></p>