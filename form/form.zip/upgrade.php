<h4>Upgrade Level</h4>
<p><label for='username'><span>Username </span></label><input class='input-field' placeholder='Masukan Username' type='text' id='username' style='width: 170px;'></p>
<p><label for='tipe'><span>Upgrate To</span></label><select id='tipe' class='select-field' style='width: 170px;'>
<option value='2'>Agen VIP</option>
</select></p>
<p><label for='submit'><span></span></label><p><input type='submit' name='submit' class='button btn btn-warning btn-large' value='Submit' onclick="upgrade();"/></p>
