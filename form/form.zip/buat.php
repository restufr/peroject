<h4>Generate Voucher Saldo</h4>
<p><label for='jumlah'><span>Jumlah Saldo </span></label><input class='input-field' placeholder='Jumlah Saldo' type='text' id='jumlah' style='width: 170px;'></p>
<p><label for='submit'><span></span></label><p><input type='submit' name='submit' class='button btn btn-warning btn-large' value='Submit' onclick="generate();"/></p>