<?php
mysql_connect('localhost', 'xhack_db', 'rizki123') or die ('Koneksi Gagal! ');
mysql_select_db('xhack_db');
?>