<h4>Perpanjang Data</h4>
<p><label for='username'><span>HDSN </span></label><input class='input-field' placeholder='HDSN Costumer' type='text' id='username' style='width: 170px;'></p>
<p><label for='durasi'><span>Durasi  </span></label><select id='durasi' class='select-field' style='width: 170px;'>
<option value='3'>3 Hari</option>
<option value='7'>7 Hari</option>
<option value='14'>14 Hari</option>
<option value='30'>30 Hari</option>
</select></p>
<p><label for='submit'><span></span></label><p><input type='submit' name='submit' class='button btn btn-warning btn-large' value='Submit' onclick="perpanjang();"/></p>