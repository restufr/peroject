<h4>Isi Saldo</h4>
<p><label for='kode'><span>Kode Voucher</span></label><input class='input-field' type='text' id='c1' value='XH' style='width: 50px;' disabled> -
<input class='input-field' type='text' id='c2' style='width: 100px;'></p>
<p><label for='submit'><span></span></label><p><input type='submit' name='submit' class='button btn btn-warning btn-large' value='Submit' onclick="topup();"/></p>