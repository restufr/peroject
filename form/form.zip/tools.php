<h4>Ganti Data/Hapus Data</h4>
<p><label for='hdsn'><span>HDSN Lama </span></label><input class='input-field' placeholder='Diisi Jika Hapus Data ' type='text' id='hdsn' style='width: 170px;'></p>
<p><label for='hdsn2'><span>HDSN Baru </span></label><input class='input-field' placeholder='Diisi Jika Ganti Data' type='text' id='hdsn2' style='width: 170px;'></p>
<p><label for='tipe'><span>Tipe</span></label><select id='tipe' class='select-field' style='width: 170px;'>
<option value='1'>Hapus</option>
<option value='2'>Ganti Data</option>
</select></p>
<p><label for='submit'><span></span></label><p><input type='submit' name='submit' class='button btn btn-warning btn-large' value='Submit' onclick="tools();"/></p>
